<?php
$url = substr($_SERVER["SCRIPT_NAME"],strrpos($_SERVER["SCRIPT_NAME"],"/")+1);
$page_title = ucfirst(substr($url, 0, strrpos($url, '.')));

if($url=='index.php') {
	$page_title = 'Home';
} else if(isset($_GET['type'])) {
	$type = $_GET['type'];
	$page_title = ucfirst($type);
} else {
	header('Location:index.php');
}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"
	"http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">

<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
	<title><?php echo $page_title . ' - '; ?>Project Transit | Mass Transporation Advocacy</title>
	<link rel="stylesheet" href="styles.css" type="text/css" media="screen" />
	<link rel="shortcut icon" href="favicon.ico" type="image/ico" />
</head>
<body>
<div id="wrap">
	<div id="head">
		<h1 id="logo"><span id="title">Project Transit</span></h1>
		<div id="nav">
			<a href="page.php?type=contact" class="link<?php if($type=='contact') { echo ' active'; } ?>"><span class="atext">contact</span></a>
			<a href="page.php?type=places" class="link<?php if($type=='places') { echo ' active'; } ?>"><span class="atext">places</span></a>
			<a href="page.php?type=about" class="link<?php if($type=='about') { echo ' active'; } ?>"><span class="atext">about</span></a>
			<a href="index.php" class="link<?php if($url=='index.php') { echo ' active'; } ?>"><span class="atext">home</span></a>
		</div>
	</div>
