<?php
include('_includes/head.php');
?>
	<div id="feature" class="small <?php echo $type; ?>">&nbsp;</div>
<?php
switch ($type) {
    case 'about': // ----------------------------------------------------------------------------------------------------------------> About
?>
	<div id="content" class="center">
		<h1>We have a passion for <span class="gray">protecting</span> our planet through the use of public and <span class="gray">mass transportation</span>.</h1>
	</div>
	<div id="content_wrap">
		<div class="right">
			<p>The goal of our site is to cause people to rethink their preconceived notions about mass transportation, and to spark a dialogue about what we love and what we'd like to see improved.</p>
			<p>While car manufacturers spend millions of dollars glamorizing driving a car (with more than a little help from Hollywood), we want to show the romance in taking the train, hopping on a bus, or riding the subway.</p>
			<p>Utilizing public transportation makes a lot of sense - it reduces your carbon foorprint, saves money - but it also allows valuable time to reflect on your day, and to drink in the sights and sounds of the city, without the stress and headaches involved in fighting rush hour traffic from the insulated bubble of an automobile.</p>
			<p>We encourage you to join the conversation, and ride with love!</p>
		</div>
		<div class="left"><h2><span class="gray">Our</span> Mission</h2></div>
		<br class="clear" />
		<div class="right">
        	<p>We are creatives who believe that art is the most powerful medium for promoting our message.</p>
        	<p>Donating our time and talent is our way of giving back and getting involved with a cause we care about.</p>
		</div>
		<div class="left"><h2><span class="gray">Who</span> We Are</h2></div>
		<br class="clear" />
<?php
        break;
    case 'places': // ----------------------------------------------------------------------------------------------------------------> Places
?>
	<div id="content_wrap">
		<div class="right">
        	<p><a href="http://www.transitchicago.com/maps/rail/rail.html" target="_blank">Chicago CTA</a></p>
        	<p><a href="http://www.1154lill.com/home/" target="_blank">1154 Lill</a></p>
        	<p><a href="http://www.merchantcircle.com/business/Deadwax.Record.Store.773-529-1932" target="_blank">Dead Wax</a></p>
        	<p><a href="http://www.millenniumpark.org/artandarchitecture/mccormick_tribune.html" target="_blank">Ice Skating in Millennium Park</a></p>
        	<p><a href="http://chicago.metromix.com/restaurants/ice_cream_frozen_yogurt/ghirardelli-chocolate-shop-and-magnificent-mile/134607/content" target="_blank">Ghirardelli-Chocolate-Shop</a></p>
        	<p><a href="http://www.sephora.com" target="_blank">Sephora</a></p>
        	<p><a href="http://www.russianteatime.com" target="_blank">Russian Tea Time</a></p>
		</div>
		<div class="left"><h2><span class="gray">Chicago</span></h2></div>
		<br class="clear" />
		<div class="right">
        	<p><a href="http://www.metro.net/default.asp" target="_blank">Los Angeles County MTA</a></p>
        	<p><a href="http://www.planetfunk.com" target="_blank">Planet Funk</a></p>
        	<p><a href="http://www.freepeople.com" target="_blank">Free People</a></p>
        	<p><a href="http://www.olvera-street.com/html/olvera_street.html" target="_blank">Olvera Street</a></p>
        	<p><a href="http://www.chinatownla.com" target="_blank">Chinatown Los Angeles</a></p>
		</div>
		<div class="left"><h2><span class="gray">Los Angeles</span></h2></div>
		<br class="clear" />
		<div class="right">
        	<p><a href="http://www.nashvillemta.org" target="_blank">Nashville MTA</a></p>
        	<p><a href="http://www.12south.org" target="_blank">12 South Neighborhood</a></p>
        	<p><a href="http://www.katyk.com" target="_blank">Katy K Ranch Dressing</a></p>
        	<p><a href="http://www.themallatgreenhills.com" target="_blank">The Mall at Green Hills</a></p>
		</div>
		<div class="left"><h2><span class="gray">Nashville</span></h2></div>
		<br class="clear" />
		<div class="right">
        	<p><a href="http://www.mta.info/nyct/" target="_blank">NYC MTA</a></p>
        	<p><a href="http://www.thepondatbryantpark.com/shop_holiday.php" target="_blank">Bryant Park Holiday Shops</a></p>
        	<p><a href="http://www.maxbrenner.com/home.aspx" target="_blank">Max Brenner</a></p>
        	<p><a href="http://www.sympathyforthekettle.com" target="_blank">Sympathy for the Kettle</a></p>
		</div>
		<div class="left"><h2><span class="gray">New York City</span></h2></div>
		<br class="clear" />
<?php
        break;
    case 'contact': // ----------------------------------------------------------------------------------------------------------------> Contact
?>
	<div id="content" class="center">
		<h1>If my energies were not spent on <span class="yellow">navigating the road</span>, I wonder where my daydreams would take me?</h1>
	</div>
	<div id="content_wrap">
		<div class="right">
			<p>Get in touch! We'd love to answer your questions as well as hear your feedback.</p>
			<p>For general inquiries please contact <a href="mailto:info@projecttransit.com"><span class="yellow">info@projecttransit.com</span></a>.</p>
			<p>For press inquiries please contact <a href="mailto:press@projecttransit.com"><span class="yellow">press@projecttransit.com</span></a>.</p>
		</div>
		<div class="left"><h2><span class="yellow">Contact</span> Us</h2></div>
		<br class="clear" />
<?php
        break;
} // end switch
?>
	</div>
<?php
include('_includes/foot.php');
?>
