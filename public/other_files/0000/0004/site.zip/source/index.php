<?php
include('_includes/head.php');
?>
	<div id="feature" class="large bus">&nbsp;</div>
	<div id="content" class="center">
		<h1><span class="blue">One person</span> using mass transit instead of driving their car would save an average of <span class="blue">200 gallons of fuel</span> per year.</h1>
	</div>
<?php
include('_includes/foot.php');
?>
